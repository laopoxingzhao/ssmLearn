package com.hu.service;

import java.util.List;

public interface UserService {

    int insertUser(User user);

    List<User> selectUser();

    User selectUserByName(String username);

    class User {
    }
}
