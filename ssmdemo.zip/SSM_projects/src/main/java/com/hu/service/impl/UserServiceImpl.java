package com.hu.service.impl;


import com.hu.domain.User;
import com.hu.mapper.UserMapper;
import com.hu.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service("userService")
public class UserServiceImpl implements UserService {

    @Autowired
    UserMapper userMapper;

    @Override
    public int insertUser(User user) {
        return 0;
    }

    @Override
    public List<User> selectUser() {
        return null;
    }

    @Override
    public User selectUserByName(String username) {
        return null;
    }
}
