package com.hu.controller;


import com.hu.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;

import javax.annotation.Resource;

@Controller
public class UserController {

//    @Autowired
//    @Qualifier("userService")
    @Resource(name = "userService")
    UserService userService;




}
