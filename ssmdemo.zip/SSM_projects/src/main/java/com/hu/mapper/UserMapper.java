package com.hu.mapper;

import com.hu.domain.User;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;


public interface UserMapper {

    int insertUser(User user);

    List<User> selectUser();

    User selectUserByName(String username);

}
