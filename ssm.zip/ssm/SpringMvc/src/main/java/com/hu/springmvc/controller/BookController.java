package com.hu.springmvc.controller;


import com.hu.springmvc.Book;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

@Controller

public class BookController {


    @RequestMapping("book")
    @ResponseBody
    public void book(String name,int age){
    //http://localhost:8080/book?name=jjjj&age=555
//       参数名一致
        System.out.println(name+age);
    }
    @RequestMapping("book1")
    @ResponseBody
    public void book1(Book book){
    //http://localhost:8080/book1?name=胡&id=555
    //       参数名一致
        System.out.println(book);
    }
    @RequestMapping("book2")
    @ResponseBody
    public void book2(@RequestParam("name") String name,@RequestParam("sss") int age){
//      @RequestParam  参数绑定
        /*
        * value = "name",参数名
        * required = false,是否必须有此参数，
        * defaultValue =  没有指定请求参数时，使用默认值
        * */
//        http://localhost:8080/book2?name=%E8%83%A1&sss=555
        System.out.println(name+age);
    }
    @RequestMapping("book2/{name}")
    @ResponseBody
    public void book2(@PathVariable("name") String name){
        /*
        @PathVariable 映射 URL 绑定的占位符
        通过 @PathVariable 可以将 URL 中占位符参数绑定到控制器处理方法的入参中:URL 中的 {xxx} 占位符可以通过
        @PathVariable(“xxx”) 绑定到操作方法的入参中
        */
//        http://localhost:8080/book2?name=%E8%83%A1&sss=555
        System.out.println(name);
    }
    @RequestMapping("book3")
    @ResponseBody
    public void book3(@RequestHeader("user-agent") String s,@CookieValue("JSESSIONID") String ss){
        System.out.println(s+'\n'+ss);
    }


}
