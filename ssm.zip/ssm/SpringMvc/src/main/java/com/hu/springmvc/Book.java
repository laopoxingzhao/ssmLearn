package com.hu.springmvc;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

public class Book {
    @Override
    public String toString() {
        return "Book{" +
                "id=" + id +
                ", Name='" + Name +
                '}';
    }

    private  Integer id;

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Book() {
    }


    private String Name;








    public Book(Integer id, String name) {
        this.id = id;
        Name = name;
    }

    public Integer getId() {
        return id;
    }


}
