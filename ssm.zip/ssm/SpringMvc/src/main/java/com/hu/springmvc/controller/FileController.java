package com.hu.springmvc.controller;


import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpSession;
import java.io.File;
import java.io.IOException;

@Controller
public class FileController {


    @RequestMapping("file")
    @ResponseBody
    public String a(String aah,MultipartFile uploadfile) throws IOException {//
        System.out.println(aah);
        System.out.println(uploadfile);

        String na = uploadfile.getOriginalFilename();
        uploadfile.transferTo(new File("E:\\aaa\\"+na));

        return "/UpLoad";
    }


    @RequestMapping("/f")
    public String f(){

        return "/UpLoad";
    }
    @RequestMapping("/ff")
    public String ff(){

        return "/../index";
    }

    @RequestMapping("/fff/{username}/{password}")
    @ResponseBody
    public String fff(@PathVariable("username") String username,
                      @PathVariable("password") String password,HttpSession session){
        System.out.println(username);
        session.setAttribute("username",username);
        session.setAttribute("password",password);
        return "/../index";
    }
    @RequestMapping("/ffff")
    @ResponseBody
    public String fff(){

        return ".  dd./index";
    }



}
