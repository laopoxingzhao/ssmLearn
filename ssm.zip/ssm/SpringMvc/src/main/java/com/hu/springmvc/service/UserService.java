package com.hu.springmvc.service;

import org.springframework.stereotype.Component;

@Component
public class UserService {
}
