package com.hu.Spring.Aop;

import java.lang.annotation.Target;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;


public class JDKproxy{

    protected void befor(){
        System.out.println("qian");
    }
    protected  void  after(){
        System.out.println("hou");
    }

    public Object Target(Object o){

        Object o1 = Proxy.newProxyInstance(
                o.getClass().getClassLoader(),
                o.getClass().getInterfaces(),
                new InvocationHandler() {
                    @Override
                    public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
                        befor();
                        Object invoke = method.invoke(o, args);
                        after();
                        return invoke;
                    }
                }
        );

        return o1;
    }
}
