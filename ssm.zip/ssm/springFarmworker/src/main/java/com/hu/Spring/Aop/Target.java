package com.hu.Spring.Aop;

import org.springframework.stereotype.Component;

@Component("Target")
public class Target {
    public  void a(){
        System.out.println("a");
    }


}
