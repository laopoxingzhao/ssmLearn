package com.hu.Spring.Dao.impl;

import com.hu.Spring.Dao.UserDao;

public class UserDaoImpl implements UserDao {
    @Override
    public void run() {

            System.out.println("User save");

    }
}
