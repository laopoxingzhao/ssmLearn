package com.hu.Spring.Dao;

public interface UserDao {
    public void run();
}
