package com.hu.Spring.Aop;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.stereotype.Component;

@Component("myAspect")
@Aspect//注解声明切面  如果要用这些注解需加上aop自动代理 <aop:aspectj-autoproxy/>
public class MyAspect {
//    切面类
    //切点
    @Pointcut(value ="execution(* com.hu.Spring.Aop.Target.*(..) )")
    public void  pointcut(){

    }



    @Before("execution(* com.hu.Spring.Aop.Target.*(..))")
    public void befor(){
        System.out.println("qian");
    }
    public void after(){
        System.out.println("最终通知");
    }
    public Object arround(ProceedingJoinPoint point) throws Throwable{
        System.out.println("环绕前增强");
        Object o = point.proceed();//环绕方法
        System.out.println("环绕hou增强");
        return o;
    }

    public void afterThrowing(){
        System.out.println("异常抛出增强");
    }
    @AfterReturning(value = "pointcut()")
    public  void afterreturning(){
        System.out.println("后置增强");

    }
}
